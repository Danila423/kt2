using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BarterAppAPI.Data;
using BarterAppAPI.Models;
using System.Threading.Tasks;

namespace BarterAppAPI.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginRequest loginRequest)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == loginRequest.Email);

            if (user == null)
            {
                return Unauthorized(new { message = "Пользователь не найден." });
            }

            if (user.Password != loginRequest.Password)
            {
                return Unauthorized(new { message = "Неверный пароль." });
            }

            return Ok(new
            {
                message = "Вход выполнен успешно.",
                user = new
                {
                    user.Id,
                    user.Email,
                    user.Name,
                    user.Phone
                }
            });
        }

        


    }
}
