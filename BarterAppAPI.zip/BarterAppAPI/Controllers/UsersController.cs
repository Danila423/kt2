using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BarterAppAPI.Data;
using BarterAppAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BarterAppAPI.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UsersController(AppDbContext context)
        {
            _context = context;
        }

        // Получить список всех пользователей
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }

        // Регистрация пользователя
        [HttpPost("register")]
        public async Task<ActionResult<User>> RegisterUser(User user)
        {
            if (await _context.Users.AnyAsync(u => u.Email == user.Email))
            {
                return BadRequest(new { message = "Пользователь с таким email уже существует." });
            }

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetUsers), new { id = user.Id }, user);
        }

        // Получить профиль текущего пользователя
        [HttpGet("profile/{id}")]
        public async Task<ActionResult<User>> GetProfile(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user == null)
            {
                return NotFound(new { message = "Пользователь не найден." });
            }

            return Ok(new
            {
                user.Id,
                user.Email,
                user.Name,
                user.Phone
            });
        }

        // Обновление профиля
        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateProfile(int id, [FromBody] User updatedUser)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
            {
                return NotFound(new { message = "Пользователь не найден." });
            }

            if (await _context.Users.AnyAsync(u => u.Email == updatedUser.Email && u.Id != id))
            {
                return BadRequest(new { message = "Email уже используется другим пользователем." });
            }

            user.Name = updatedUser.Name;
            user.Phone = updatedUser.Phone;
            user.Email = updatedUser.Email;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Профиль успешно обновлен." });
        }


        [HttpPost("validate-password")]
        public async Task<IActionResult> ValidatePassword([FromBody] PasswordValidationRequest request)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.UserId);

            if (user == null)
            {
                return NotFound(new { message = "Пользователь не найден." });
            }

            if (user.Password != request.Password)
            {
                return Unauthorized(new { message = "Неверный пароль." });
            }

            return Ok(new { message = "Пароль подтвержден." });
        }

        [HttpPut("change-password/{id}")]
        public async Task<IActionResult> ChangePassword(int id, [FromBody] ChangePasswordRequest request)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
            {
                return NotFound(new { message = "Пользователь не найден." });
            }

            if (user.Password != request.CurrentPassword)
            {
                return BadRequest(new { message = "Текущий пароль неверен." });
            }

            user.Password = request.NewPassword;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Пароль успешно изменён." });
        }


    }
}
