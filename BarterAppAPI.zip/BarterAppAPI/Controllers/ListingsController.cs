using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BarterAppAPI.Data;
using BarterAppAPI.Models;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BarterAppAPI.Controllers
{
    [Route("api/listings")]
    [ApiController]
    public class ListingsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ListingsController(AppDbContext context)
        {
            _context = context;
        }

        // Создание нового объявления
        [HttpPost]
        public async Task<IActionResult> CreateListing([FromBody] Listing listing)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.Listings.Add(listing);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetListingById), new { id = listing.Id }, listing);
        }

        // Получение объявления по ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetListingById(int id)
        {
            var listing = await _context.Listings.FindAsync(id);
            if (listing == null)
            {
                return NotFound(new { message = "Объявление не найдено." });
            }
            return Ok(listing);
        }

        [HttpGet("user/{id}")]
        public async Task<ActionResult<IEnumerable<Listing>>> GetUserListings(int id)
        {
            var listings = await _context.Listings
                .Where(l => l.UserId == id)
                .ToListAsync();

            if (listings == null || listings.Count == 0)
            {
                return NotFound(new { message = "Объявления не найдены." });
            }

            return Ok(listings);
        }
    }
}
