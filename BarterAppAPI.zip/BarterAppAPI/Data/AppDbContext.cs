using Microsoft.EntityFrameworkCore;
using BarterAppAPI.Models;

namespace BarterAppAPI.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public DbSet<Listing> Listings { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}
