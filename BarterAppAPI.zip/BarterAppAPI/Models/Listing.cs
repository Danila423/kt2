using System;
using System.ComponentModel.DataAnnotations;

public class Listing
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Название обязательно.")]
    public string Title { get; set; }

    [Required(ErrorMessage = "Состояние обязательно.")]
    public string Condition { get; set; }

    [Required(ErrorMessage = "Описание обязательно.")]
    public string Description { get; set; }

    [Required(ErrorMessage = "Категория обязательна.")]
    public string Category { get; set; }

    [Required(ErrorMessage = "Фотография обязательна.")]
    public string PhotoPath { get; set; }

    public int UserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
