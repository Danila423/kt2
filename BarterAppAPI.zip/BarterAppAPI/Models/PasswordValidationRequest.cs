namespace BarterAppAPI.Models
{
    public class PasswordValidationRequest
    {
        public int UserId { get; set; }
        public string Password { get; set; }
    }
}
