import Foundation

protocol MyListingsPresenterProtocol: AnyObject {
    func loadUserListings()
}

class MyListingsPresenter: MyListingsPresenterProtocol {
    weak var view: MyListingsViewProtocol?
    var interactor: MyListingsInteractorProtocol?
    var router: MyListingsRouterProtocol?

    func loadUserListings() {
        interactor?.fetchUserListings { [weak self] result in
            switch result {
            case .success(let listings):
                self?.view?.showListings(listings)
            case .failure(let error):
                self?.view?.showError(message: error.localizedDescription)
            }
        }
    }
}
