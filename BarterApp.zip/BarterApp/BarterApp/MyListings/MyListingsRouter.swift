import UIKit

protocol MyListingsRouterProtocol: AnyObject {
    func navigateBackToProfile()
}

class MyListingsRouter: MyListingsRouterProtocol {
    weak var viewController: UIViewController?

    func navigateBackToProfile() {
        viewController?.navigationController?.popViewController(animated: true)
    }

    static func createModule() -> UIViewController {
            let view = MyListingsView()
            let presenter = MyListingsPresenter()
            let interactor = MyListingsInteractor()
            let router = MyListingsRouter()

            view.presenter = presenter
            presenter.view = view
            presenter.interactor = interactor
            presenter.router = router

            return view
        }
}
