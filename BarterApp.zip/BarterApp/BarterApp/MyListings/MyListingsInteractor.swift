import Foundation

protocol MyListingsInteractorProtocol: AnyObject {
    func fetchUserListings(completion: @escaping (Result<[Listing], Error>) -> Void)
}

class MyListingsInteractor: MyListingsInteractorProtocol {
    
    private let baseUrl = "http://localhost:5000/api/listings/user/"
    private var currentUserId: Int? {
        let id = UserDefaults.standard.integer(forKey: "loggedInUserId")
        return id == 0 ? nil : id
    }
    
    func fetchUserListings(completion: @escaping (Result<[Listing], Error>) -> Void) {
        guard let userId = currentUserId else {
            let error = NSError(domain: "AuthError", code: -1,
                                userInfo: [NSLocalizedDescriptionKey: "Пользователь не авторизован"])
            completion(.failure(error))
            return
        }
        
        guard let url = URL(string: "\(baseUrl)\(userId)") else {
            let error = NSError(domain: "URLError", code: -1,
                                userInfo: [NSLocalizedDescriptionKey: "Неверный URL"])
            completion(.failure(error))
            return
        }
        

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode),
                  let data = data else {
                DispatchQueue.main.async {
                    let statusCode = (response as? HTTPURLResponse)?.statusCode ?? -1
                    let error = NSError(domain: "HTTPError", code: statusCode,
                                        userInfo: [NSLocalizedDescriptionKey: "Ошибка получения данных с сервера"])
                    completion(.failure(error))
                }
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let listings = try decoder.decode([Listing].self, from: data)
                DispatchQueue.main.async {
                    completion(.success(listings))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
        task.resume()
    }
}
