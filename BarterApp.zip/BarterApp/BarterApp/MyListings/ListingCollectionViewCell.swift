import UIKit

class ListingCollectionViewCell: UICollectionViewCell {
    static let identifier = "ListingCollectionViewCell"
    
    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 2
        label.font = UIFont.systemFont(ofSize: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        contentView.addSubview(titleLabel)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor),
            

            titleLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 4),
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 4),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -4),
            titleLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -4)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with listing: Listing) {
            titleLabel.text = listing.title
            
            // Используем статическую Base64 строку для изображения(пока заглушка)
            let staticBase64 = "iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAjVBMVEUAAAD///3///8EBAT///v8/Pr8/PwICAjz8/MvLy/o6Oj5+fmlpaWCgoD5+fcMDAzCwsLPz89gYGDu7u5lZWXd3d2cnJw4ODh5eXmnp6fh4eHIyMa6urpbW1vV1dVwcG9NTU2KioqwsK4dHR2QkJBFRUUkJCSHh4c+Pj5HR0c5OThTU1IXFxZ1dXYgIB/h4R5YAAAJr0lEQVR4nO2di3LiOgyGHaW5uiRACLfSltLr7nbP+z/esRTo0gtYbkiMO/5mdmZLgfrHtizJshHC4/F4PB6Px+PxeDwej8fj8Xg8nlMQ4j8F/Wf/cXwEH8dfhOGXr3WDUCSNhD0V9N+EpKnfuqwOScLk+O8bqY7zNB5P5nfD0TLdUtXD1fN8Mr7Ots9wWePLdHhVwyHq0XBxbbuJpoRhuZ1pv+fTqhESHKL5dbEYjOm1ZYiD9ty7NCnRtIhsMMohig5q26NQQot68fiqXhaWZHwtazgOGZbpEIDUsSRGgfooAPLNWr20dGDt+LMpVKdgq9kCC3oqyOUg07+/bf5cXQSoLiKFHIkFaqTnqzm5XNkWcIhQ0NI+qY/YFS2N4bn89dFFOAcS8sBmQ9lC31ZhDNX0XiSNVT0fQtUisUkBZHuFsYR8gkuHbVHv2A5Q1br2CmUspVzNzm7NmEoaYfEJ+jBWQwGWt7YVvZHgAP2d8+wml0gtOKv7JryyTqhs6HUeRcVJFUZBGoweyT5bJynFXVwEJxUYNKtkdX0mk3EqZZRGqk2nQ42IqCiidG5bGzFVxi84+SglhUXxYFcbGYKhsu+t1oijwMKquUE7MAWp7HtnCoN4ajOaUh/uApfodqugRiHYHahqDqKr1qXCGJ4tCpwrgeiDdKgQpEytpHLU9E/ErbKfF92JexMJmY28qvqLZUWxaw8Sb7L+rQ0m5YdwWmf0iMSNFf/tgaLdXiQWxaD3TkzEYx4H3GRTW6Iofe1RHO0jhfc3fAsa7TKL0d5DJh+NenKNU7+voUpmbXAsl/2pgU3iLXr7uXmILRK93rmKRPszqKHIlsD31Zp86PstCyMzrD6NosLUTV8K1d/ZqJWY34dBBGk9mv7JdjyOr+rcIPGI7/AgPu2zdqdPCBVPGPjbUD18Trtk8yl/pCuJedabD67+zBWjZRLdOYnZqdX60Fv9HUEcMc0OdWJfAl8qhsJYSZRK33CMcVb51Vsl4nWecw0rVP3oI1M65Qwu0gf5nDLiXyewyfqvKCejR8KgL4lCVIwGBRj7w2omykQc2oWgBS65S1kKYxj2JC8Uc45AjOxgtU11HDDzTc2J+JvyFMJTXwo3LAuoRik3PB9jNlI3GaG/cP8pZSUOAVMsDHCODqAodMk6FWqPOla2Ywwsb4SGKOf9cCNt1Xg+mj7MZ11ra7hihYVw84q7gHpoov631L4ppkt6sqY1K/sLL8xMZ0h1b3PtwECF/UzEW708/AhMM2TaaEw5D3Aj+vDcBqDdolAD7sbMsofiQeej0sZi89yOuQRt4KMUGm5wqnhMF6vEuAMr+kjyV/pdpiIaGTZDNXupUYgCIetDIUQ6u6460TQOUIuiztnFKAUmHY9RTAMLhkMT5d+YLdfaPlR0vk+jRkjGUKgaYjiWQnQkGAo3HQn71w5cuPQKi7VpvQ9XYffhRahMqb4LR6VpjpqvsGM7E1IuX6twZVx/b9KHXWpES70BXHlhW93TVKLtQT+YHzBQz+cq7LQTqTxPYmFWvC8p3tdInkdoumqppw84ClcdF/TRruGfxTB/n93dV4i+1cY8s6kUjnirRbcr/i7fcp9lL7ebm7rOU/hILOFZfD4ko0eXv6N3H59e1DuSt7M8W7Lx4Plh8f64QRzfmo9SIf7qMsz05v8Ja6UZs+fVcHiDxw9iwyCuiQ/Fla4qB5026KbxfF4fx+PJdWlmDMISz2isQVebipM97qjhjFaKvcHzdX77yGvRO7jR1qwA2TB7hFuJyTcWCgwspNT1IVgtrfnXh6G5kUnQn4m1fYilw+dTOMyEzh+qMTpJOQFLk6ZxjDKkHsw5KeaYokPHUB2IPcjbe1IKX2w32Bw8p/GQ8g65AQZlzqFs0h0UBUth7NggJYtbCt5mK52Ei3PbbTajpIOG9yte3RF2snnyxy60bM5GwKpZoXKqPHNLIR5jn1XArTuKAhicx/kSNngWLAXJrS+OgvRMzgixaAJplo1pokIsT5rYbrUBlDlPLplVNNs0ic2owhgcbU9XkEYpWyHkfdaXtkYJnCwhDVg1Jk1mJD2XM15cbisZYW0zW+GDMwvFa9mcJOLXF6dY+3d57vcs/KPE6owhGFRuqtAfw8K+Sktbo6yosjHYLVyFKmZaZg5dYqME1mZnwSDOfwuH+lAJpHNSBgqrNWYCXPBn8PIZcZ3zhufbFohMfzljRtHGzHJmgX7jq6nRLNfbO2scQC0Ta9p84a/zMq4mvRTQnAYUKC+YN7psfTU8rl46o1A8LXHvxcDfhnTcXONy/gopZ/iUGljQFHeZ07UzRoYK1vPUwJNJZQrpizs38iVU4KDiWPa5fdWDy1/bW0VcICyVs00HTLgKJdQz2tZwRaEYVzix+Kfaoc6abNz5K2w22zLWEZRgV74iYSHciZfIZd4we67x1aRc2G61AZRWuy2M1nm4cymWoOU6NVvn/zow+/4R0kk35u01jcCJaamDXZTAR84WNoFXtS1tt9iUcHczAUuhpAu+nJmCBLprbIWS9kBDdxYKBKum+Xm1wduRRJfYcM9rA6zphknH9ImZNvvblOAqV9vBSgtkoN0DjRuJuaMCxUib/W1qjJfnd9klj6dcu1NP63z94kw8/4E5VoVqFOIo7eXE1qmhFt+BdpRKGS8fbTf2e6DEFfbQcYVxbOe6svaQb0Kly5o+xNp+2439FjSxyIxo5uHQVSNDSRbQzkOofjlWCvSOyfE+xAPFdMLGVTD41Y5S6OmehE7Ao3x6ha7Owt3FgzqF7toZQacMtAojuHMuHnwDd7WvNJaGiirdJeQojJw7JLJHiLGTbh5WjrqkW8obnUJYOlV0+IlXjUI1DWvbbWyHTmHgvMJSOw9dV6i3NC4eR3vHD1fIWS2cVoiu2BUcPTNSRJHL8zBsfJqjdUJF4LZCjC3wjs+DAqPAbYUquFjA0e8VUAqdOinyAZyHW7ftMKOeLuz0fB9tbOto8PuOIxrczV/sQbctHOKHdOFREc7maN6gL8/NDpKc29ccmqPaP6/zgyxtfg/QacDS0vjIehi7naYRmDOdxvKgvlSCy6m2LZdwWKGM4Ty+Ha8Vi+PxocsJ4S2XXqHzeIW229cer9B2+9rjFdpuX3u8Qtvta49XaLt97fEKbbevPV6h7fa1xyu03b72HFV48TMUBhdfsPvi1Z+rELxCd1Dz8IcrPJAv3Sl0fuMiEdnX31ux3bao/rPdwtYkYlKnh6hq1258/Iz269BduZ/lIEmYHPgu4Oa3Dp46/MBxBe4d3PZ4PB6Px+PxeDwej8fj8Xg8Hs/58j8oAHMLbsPgfQAAAABJRU5ErkJggg=="
            
            if let imageData = Data(base64Encoded: staticBase64),
               let image = UIImage(data: imageData) {
                imageView.image = image
            } else {
                imageView.image = UIImage(systemName: "photo")
            }
        }
}
