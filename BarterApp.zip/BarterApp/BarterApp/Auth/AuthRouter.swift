import UIKit

protocol AuthRouterProtocol {
    func navigateToRegistration()
    func navigateToProfile()
}

class AuthRouter: AuthRouterProtocol {
    weak var viewController: UIViewController?

    func navigateToRegistration() {
        let registrationVC = RegistrationRouter.createModule()
        viewController?.navigationController?.pushViewController(registrationVC, animated: true)
    }
    
    func navigateToProfile() {
        let profileVC = ProfileRouter.createModule()
        viewController?.navigationController?.pushViewController(profileVC, animated: true)
    }

    static func createModule() -> UIViewController {
        let view = AuthView()
        let presenter = AuthPresenter()
        let interactor = AuthInteractor()
        let router = AuthRouter()

        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        router.viewController = view

        return view
    }
}

