

import Foundation

protocol AuthPresenterProtocol: AnyObject {
    var router: AuthRouterProtocol? { get set }
    func login(email: String, password: String)
}

class AuthPresenter: AuthPresenterProtocol {
    weak var view: AuthViewProtocol?
    var interactor: AuthInteractorProtocol?
    var router: AuthRouterProtocol?

    func login(email: String, password: String) {
        let user = UserData(email: email, password: password)
        interactor?.login(user: user) { [weak self] result in
            switch result {
            case .success:
                print("Успешный вход")
                self?.view?.showSuccess()
            case .failure(let error):
                print("Ошибка входа: \(error.localizedDescription)")
                self?.view?.showError(message: error.localizedDescription)
            }
        }
    }

}


