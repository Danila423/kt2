
import Foundation

protocol AuthInteractorProtocol: AnyObject {
    func login(user: UserData, completion: @escaping (Result<Bool, Error>) -> Void)
}

class AuthInteractor: AuthInteractorProtocol {
    func login(user: UserData, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: "http://localhost:5000/api/auth/login") else {
            let err = NSError(domain: "InvalidURL",
                              code: -1,
                              userInfo: [NSLocalizedDescriptionKey: "Некорректный URL для авторизации"])
            DispatchQueue.main.async {
                completion(.failure(err))
            }
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: String] = [
            "email": user.email,
            "password": user.password
        ]
        
        print(body)

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        } catch {
            DispatchQueue.main.async {
                completion(.failure(error))
            }
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                let err = NSError(domain: "NoHTTPResponse",
                                  code: -1,
                                  userInfo: [NSLocalizedDescriptionKey: "Ответ не содержит статус‑код"])
                DispatchQueue.main.async {
                    completion(.failure(err))
                }
                return
            }

            guard (200...299).contains(httpResponse.statusCode) else {
                let serverMessage: String
                if let data = data,
                   let respString = String(data: data, encoding: .utf8) {
                    serverMessage = "Ошибка входа: \(respString)"
                } else {
                    serverMessage = "Ошибка входа, код \(httpResponse.statusCode)"
                }

                let err = NSError(domain: "LoginError",
                                  code: httpResponse.statusCode,
                                  userInfo: [NSLocalizedDescriptionKey: serverMessage])
                DispatchQueue.main.async {
                    completion(.failure(err))
                }
                return
            }

            guard let data = data else {
                let err = NSError(domain: "NoData",
                                  code: -1,
                                  userInfo: [NSLocalizedDescriptionKey: "Нет данных в ответе от сервера"])
                DispatchQueue.main.async {
                    completion(.failure(err))
                }
                return
            }

            do {
                if let jsonResponse = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let userDict = jsonResponse["user"] as? [String: Any],
                   let userId = userDict["id"] as? Int {
                    UserDefaults.standard.set(userId, forKey: "loggedInUserId")

                    print("Успешный вход. ID пользователя: \(userId)")
                    print(userDict)

                    DispatchQueue.main.async {
                        completion(.success(true))
                    }
                } else {
                    let err = NSError(domain: "InvalidResponse",
                                      code: -1,
                                      userInfo: [NSLocalizedDescriptionKey: "Неправильный формат ответа"])
                    DispatchQueue.main.async {
                        completion(.failure(err))
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }.resume()
    }

}
