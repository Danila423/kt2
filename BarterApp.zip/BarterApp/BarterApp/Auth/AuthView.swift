import UIKit

protocol AuthViewProtocol: AnyObject {
    func showSuccess()
    func showError(message: String)
    
}


class AuthView: UIViewController, AuthViewProtocol {
    var presenter: AuthPresenterProtocol?

    private let emailTextField = UITextField()
    private let passwordTextField = UITextField()
    private let loginButton = UIButton()
    private let registerButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .white

        emailTextField.placeholder = "Электронная почта"
        passwordTextField.placeholder = "Пароль"
        passwordTextField.isSecureTextEntry = true

        loginButton.setTitle("Войти", for: .normal)
        loginButton.backgroundColor = .black
        loginButton.addTarget(self, action: #selector(loginTapped), for: .touchUpInside)

        registerButton.setTitle("Создать аккаунт", for: .normal)
        registerButton.backgroundColor = .black
        registerButton.addTarget(self, action: #selector(registerTapped), for: .touchUpInside)

        let stackView = UIStackView(arrangedSubviews: [emailTextField, passwordTextField, loginButton, registerButton])
        stackView.axis = .vertical
        stackView.spacing = 10

        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    @objc private func loginTapped() {
        presenter?.login(email: emailTextField.text ?? "", password: passwordTextField.text ?? "")
    }

    @objc private func registerTapped() {
        presenter?.router?.navigateToRegistration()
    }

    func showSuccess() {
        print("Авторизация успешна!")
        presenter?.router?.navigateToProfile()
    }

    func showError(message: String) {
        print("Ошибка: \(message)")
    }
}
