import Foundation


protocol RegistrationPresenterProtocol: AnyObject {
    func register(email: String, password: String, phone: String, name: String)
}

class RegistrationPresenter: RegistrationPresenterProtocol {
    weak var view: RegistrationViewProtocol?
    var interactor: RegistrationInteractorProtocol?
    var router: RegistrationRouterProtocol?

    func register(email: String, password: String, phone: String, name: String) {
        let user = RegistrationData(email: email, password: password, phone: phone, name: name)
        interactor?.register(user: user) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.view?.showSuccess()
                case .failure(let error):
                    self?.view?.showError(message: error.localizedDescription)
                }
            }
        }
    }
}
