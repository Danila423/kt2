import UIKit

protocol RegistrationRouterProtocol {
    static func createModule() -> UIViewController
}

class RegistrationRouter: RegistrationRouterProtocol {
    static func createModule() -> UIViewController {
        let view = RegistrationView()
        let presenter = RegistrationPresenter()
        let interactor = RegistrationInteractor()
        let router = RegistrationRouter()

        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router

        return view
    }
}
