import Foundation

protocol RegistrationInteractorProtocol: AnyObject {
    func register(user: RegistrationData, completion: @escaping (Result<Bool, Error>) -> Void)
}

class RegistrationInteractor: RegistrationInteractorProtocol {
    func register(user: RegistrationData, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: "http://localhost:5000/api/users/register") else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "email": user.email,
            "password": user.password,
            "phone": user.phone,
            "name": user.name
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        } catch {
            completion(.failure(error))
            return
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Ошибка запроса: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Код ответа от сервера: \(httpResponse.statusCode)")
            }

            if let data = data {
                let responseString = String(data: data, encoding: .utf8)
                print("Ответ от сервера: \(responseString ?? "пусто")")
            }

            completion(.success(true))
        }

        task.resume()
    }
}
