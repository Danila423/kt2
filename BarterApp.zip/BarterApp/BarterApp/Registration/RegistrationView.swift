import UIKit

protocol RegistrationViewProtocol: AnyObject {
    func showSuccess()
    func showError(message: String)
}

class RegistrationView: UIViewController, RegistrationViewProtocol {
    var presenter: RegistrationPresenterProtocol?

    private let emailTextField = UITextField()
    private let passwordTextField = UITextField()
    private let confirmPasswordTextField = UITextField()
    private let phoneTextField = UITextField()
    private let nameTextField = UITextField()
    private let registerButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .white

        emailTextField.placeholder = "Электронная почта"
        passwordTextField.placeholder = "Пароль"
        confirmPasswordTextField.placeholder = "Подтвердите пароль"
        phoneTextField.placeholder = "Номер телефона"
        nameTextField.placeholder = "Имя"

        passwordTextField.isSecureTextEntry = true
        confirmPasswordTextField.isSecureTextEntry = true

        registerButton.setTitle("Зарегистрироваться", for: .normal)
        registerButton.backgroundColor = .black
        registerButton.addTarget(self, action: #selector(registerTapped), for: .touchUpInside)

        let stackView = UIStackView(arrangedSubviews: [
            emailTextField, phoneTextField, nameTextField,
            passwordTextField, confirmPasswordTextField, registerButton
        ])
        stackView.axis = .vertical
        stackView.spacing = 10

        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    @objc private func registerTapped() {
        guard let email = emailTextField.text,
              let password = passwordTextField.text,
              let confirmPassword = confirmPasswordTextField.text,
              let phone = phoneTextField.text,
              let name = nameTextField.text,
              !email.isEmpty, !password.isEmpty, !confirmPassword.isEmpty, !phone.isEmpty, !name.isEmpty else {
            showError(message: "Заполните все поля!")
            return
        }

        guard password == confirmPassword else {
            showError(message: "Пароли не совпадают!")
            return
        }

        presenter?.register(email: email, password: password, phone: phone, name: name)
    }

    func showSuccess() {
        print("Регистрация успешна!")
    }

    func showError(message: String) {
        print("Ошибка: \(message)")
    }
}
