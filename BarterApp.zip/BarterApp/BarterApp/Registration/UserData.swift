import UIKit


struct UserData {
    let email: String
    let password: String
}

struct RegistrationData {
    let email: String
    let password: String
    let phone: String
    let name: String
}
