import Foundation

protocol CreateListingPresenterProtocol: AnyObject {
    func submitListing(_ listing: Listing)
}

class CreateListingPresenter: CreateListingPresenterProtocol {
    weak var view: CreateListingViewProtocol?
    var interactor: CreateListingInteractorProtocol?
    var router: CreateListingRouterProtocol?
    
    func submitListing(_ listing: Listing) {
        interactor?.createListing(listing, completion: { [weak self] result in
            switch result {
            case .success:
                self?.view?.showSuccess(message: "Объявление успешно создано!")
            case .failure(let error):
                self?.view?.showError(message: "Ошибка: \(error.localizedDescription)")
            }
        })
    }
}
