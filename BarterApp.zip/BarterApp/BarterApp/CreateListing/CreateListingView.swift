import UIKit

protocol CreateListingViewProtocol: AnyObject {
    func showSuccess(message: String)
    func showError(message: String)
}

class CreateListingView: UIViewController, CreateListingViewProtocol {
    
    var presenter: CreateListingPresenterProtocol?
    
    private let imageView = UIImageView()
    private let uploadButton = UIButton()
    private let titleTextField = UITextField()
    private let conditionTextField = UITextField()
    private let descriptionTextField = UITextField()
    private let categoryPicker = UIPickerView()
    private let submitButton = UIButton()
    
    private let categories = ["Электроника", "Одежда", "Книги", "Мебель", "Другое"]
    private var selectedCategory: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = .white
        title = "Создание объявления"
        
        imageView.backgroundColor = .lightGray
        imageView.contentMode = .scaleAspectFit
        imageView.layer.cornerRadius = 8
        imageView.clipsToBounds = true
        imageView.image = UIImage(systemName: "arrow.up")
        imageView.tintColor = .darkGray
        
        uploadButton.setTitle("Загрузить фотографию", for: .normal)
        uploadButton.backgroundColor = .black
        uploadButton.layer.cornerRadius = 8
        uploadButton.addTarget(self, action: #selector(uploadPhotoTapped), for: .touchUpInside)
        
        setupTextField(titleTextField, placeholder: "Название")
        setupTextField(conditionTextField, placeholder: "Состояние")
        setupTextField(descriptionTextField, placeholder: "Описание")
        
        categoryPicker.dataSource = self
        categoryPicker.delegate = self
        
        submitButton.setTitle("Создать объявление", for: .normal)
        submitButton.backgroundColor = .black
        submitButton.layer.cornerRadius = 8
        submitButton.addTarget(self, action: #selector(submitTapped), for: .touchUpInside)
        
        let stackView = UIStackView(arrangedSubviews: [
            imageView,
            uploadButton,
            titleTextField,
            conditionTextField,
            descriptionTextField,
            categoryPicker,
            submitButton
        ])
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.alignment = .fill
        
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalToConstant: 200)
        ])
    }
    
    private func setupTextField(_ textField: UITextField, placeholder: String) {
        textField.placeholder = placeholder
        textField.borderStyle = .roundedRect
        textField.font = UIFont.systemFont(ofSize: 16)
    }
    
    @objc private func submitTapped() {
        guard let title = titleTextField.text, !title.isEmpty,
              let condition = conditionTextField.text, !condition.isEmpty,
              let description = descriptionTextField.text, !description.isEmpty,
              let category = selectedCategory else {
            showError(message: "Все поля должны быть заполнены")
            return
        }
        
        guard let selectedImage = imageView.image,
              let imageData = selectedImage.jpegData(compressionQuality: 0.5) else {
            showError(message: "Пожалуйста, выберите фото")
            return
        }
        
        let base64String = imageData.base64EncodedString()
        
        let listing = Listing(
            title: title,
            description: description,
            category: category,
            condition: condition,
            photoBase64: "base64String"
        )
        
        presenter?.submitListing(listing)
    }
    
    func showSuccess(message: String) {
        let alert = UIAlertController(title: "Успех", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self] _ in
            self?.navigationController?.popViewController(animated: true)
        }))
        present(alert, animated: true)
    }
    
    func showError(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - UIImagePickerControllerDelegate / UINavigationControllerDelegate
extension CreateListingView: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @objc private func uploadPhotoTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        if let selectedImage = info[.originalImage] as? UIImage {
            imageView.image = selectedImage
        }
    }
}

extension CreateListingView: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int { 1 }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        categories.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int,
                    forComponent component: Int) -> String? {
        categories[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int,
                    inComponent component: Int) {
        selectedCategory = categories[row]
    }
}
