import Foundation

protocol CreateListingInteractorProtocol: AnyObject {
    func createListing(_ listing: Listing, completion: @escaping (Result<Bool, Error>) -> Void)
}

class CreateListingInteractor: CreateListingInteractorProtocol {
    
    private var currentUserId: Int? {
        return UserDefaults.standard.integer(forKey: "loggedInUserId")
    }
    
    func createListing(_ listing: Listing, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let userId = currentUserId, userId != 0 else {
            let error = NSError(domain: "AuthError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Пользователь не авторизован"])
            completion(.failure(error))
            return
        }
        
        guard let url = URL(string: "http://localhost:5000/api/listings") else {
            let error = NSError(domain: "URLError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Неверный URL"])
            completion(.failure(error))
            return
        }
        
        let parameters: [String: Any] = [
            "title": listing.title,
            "condition": listing.condition,
            "description": listing.description,
            "category": listing.category,
            "photoPath": "123",
            "userId": userId
        ]
        
        guard let jsonData = try? JSONSerialization.data(withJSONObject: parameters) else {
            let error = NSError(domain: "SerializationError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Ошибка сериализации JSON"])
            completion(.failure(error))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse, !(200...299).contains(httpResponse.statusCode) {
                let error = NSError(domain: "HTTPError", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "Сервер вернул ошибку (\(httpResponse.statusCode))"])
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }
            
            DispatchQueue.main.async {
                completion(.success(true))
            }
        }
        task.resume()
    }
}
