import Foundation

struct Listing: Decodable {
    let title: String
    let description: String
    let category: String
    let condition: String
    let photoBase64: String?
    
    
}
