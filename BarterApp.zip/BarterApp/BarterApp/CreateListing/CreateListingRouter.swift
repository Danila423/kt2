import UIKit

protocol CreateListingRouterProtocol: AnyObject {
    func navigateBackToProfile()
}

class CreateListingRouter: CreateListingRouterProtocol {
    weak var viewController: UIViewController?
    
    func navigateBackToProfile() {
        viewController?.navigationController?.popViewController(animated: true)
    }
    
    static func createModule() -> UIViewController {
        let view = CreateListingView()
        let presenter = CreateListingPresenter()
        let interactor = CreateListingInteractor()
        let router = CreateListingRouter()
        
        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        router.viewController = view
        
        return view
    }
}
