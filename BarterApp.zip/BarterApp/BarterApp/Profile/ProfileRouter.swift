import UIKit

protocol ProfileRouterProtocol: AnyObject {
    func navigateToEditProfile()
    func navigateToChangePassword()
    func navigateToLogin()
    func navigateToCreateListing()
    func navigateToMyListings()
}

class ProfileRouter: ProfileRouterProtocol {
    weak var viewController: UIViewController?

    func navigateToEditProfile() {
        let editProfileVC = EditProfileRouter.createModule()
        viewController?.navigationController?.pushViewController(editProfileVC, animated: true)
    }

    func navigateToChangePassword() {
        let changePasswordVC = ChangePasswordRouter.createModule()
        viewController?.navigationController?.pushViewController(changePasswordVC, animated: true)
    }

    func navigateToLogin() {
        viewController?.navigationController?.popToRootViewController(animated: true)
    }

    func navigateToCreateListing() {
        let createListingVC = CreateListingRouter.createModule()
        viewController?.navigationController?.pushViewController(createListingVC, animated: true)
    }
    
    func navigateToMyListings() {
        let myListingsViewController = MyListingsRouter.createModule()
        viewController?.navigationController?.pushViewController(myListingsViewController, animated: true)
    }



    static func createModule() -> UIViewController {
        let view = ProfileView()
        let presenter = ProfilePresenter()
        let interactor = ProfileInteractor()
        let router = ProfileRouter()

        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        router.viewController = view

        return view
    }
}
