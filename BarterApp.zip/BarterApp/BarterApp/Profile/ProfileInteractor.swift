import Foundation

protocol ProfileInteractorProtocol: AnyObject {
    func fetchUserProfile(completion: @escaping (Result<UserProfile, Error>) -> Void)
    func updateUserProfile(_ profile: UserProfile, completion: @escaping (Result<Bool, Error>) -> Void)
    func logoutUser(completion: @escaping (Result<Bool, Error>) -> Void)
}

class ProfileInteractor: ProfileInteractorProtocol {
    private let apiBaseUrl = "http://localhost:5000/api/users"

    func fetchUserProfile(completion: @escaping (Result<UserProfile, Error>) -> Void) {
        let userId = UserDefaults.standard.integer(forKey: "loggedInUserId")
        guard let url = URL(string: "\(apiBaseUrl)/profile/\(userId)") else {
            DispatchQueue.main.async {
                completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL"])))
            }
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse, !(200...299).contains(httpResponse.statusCode) {
                let serverMessage = String(data: data ?? Data(), encoding: .utf8) ?? "Неизвестная ошибка"
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "ServerError", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: serverMessage])))
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "NoData", code: -1, userInfo: [NSLocalizedDescriptionKey: "Нет данных в ответе"])))
                }
                return
            }

            do {
                print(333)
                if let rawString = String(data: data, encoding: .utf8) {
                    print("JSON от сервера: \(rawString)")
                }

                let profile = try JSONDecoder().decode(UserProfile.self, from: data)
                print("--------")
                print(profile)
                DispatchQueue.main.async {
                    completion(.success(profile))
                }
            } catch {
                print(123)
                if let json = try? JSONSerialization.jsonObject(with: data, options: []),
                   let dictionary = json as? [String: Any],
                   let message = dictionary["message"] as? String {
                    DispatchQueue.main.async {
                        completion(.failure(NSError(domain: "ServerError", code: -1, userInfo: [NSLocalizedDescriptionKey: message])))
                    }
                } else {
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                }
            }
        }.resume()
    }





    func updateUserProfile(_ profile: UserProfile, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: "\(apiBaseUrl)/update/1") else {
            DispatchQueue.main.async {
                completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: nil)))
            }
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        guard let body = try? JSONEncoder().encode(profile) else {
            completion(.failure(NSError(domain: "EncodingError", code: -1, userInfo: nil)))
            return
        }

        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "ServerError", code: -1, userInfo: nil)))
                }
                return
            }
            DispatchQueue.main.async {
                completion(.success(true))
            }
        }.resume()
    }

    func logoutUser(completion: @escaping (Result<Bool, Error>) -> Void) {
        DispatchQueue.main.async {
            completion(.success(true))
        }
    }
}
