import UIKit

protocol ProfileViewProtocol: AnyObject {
    func showUserProfile(_ profile: UserProfile)
    func showError(message: String)
    func showSuccess(message: String)
}

class ProfileView: UIViewController, ProfileViewProtocol {
    var presenter: ProfilePresenterProtocol?

    private let editButton = UIButton()
    private let changePasswordButton = UIButton()
    private let logoutButton = UIButton()
    private let createListingButton = UIButton()
    private let myListingsButton = UIButton()

    private let emailLabel = UILabel()
    private let nameLabel = UILabel()
    private let phoneNumberLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        presenter?.loadUserProfile()
        
        NotificationCenter.default.addObserver(self, selector: #selector(refreshProfileData), name: .profileUpdated, object: nil)
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: .profileUpdated, object: nil)
    }

    private func setupUI() {
        view.backgroundColor = .white
        title = "Профиль"


        setupLabel(emailLabel, text: "Email: ")
        setupLabel(nameLabel, text: "Имя: ")
        setupLabel(phoneNumberLabel, text: "Телефон: ")


        editButton.setTitle("Редактировать информацию", for: .normal)
        editButton.backgroundColor = .black
        editButton.addTarget(self, action: #selector(editTapped), for: .touchUpInside)

        changePasswordButton.setTitle("Изменить пароль", for: .normal)
        changePasswordButton.backgroundColor = .black
        changePasswordButton.addTarget(self, action: #selector(changePasswordTapped), for: .touchUpInside)

        logoutButton.setTitle("Выйти", for: .normal)
        logoutButton.backgroundColor = .black
        logoutButton.addTarget(self, action: #selector(logoutTapped), for: .touchUpInside)

        createListingButton.setTitle("Создать объявление", for: .normal)
        createListingButton.backgroundColor = .black
        createListingButton.layer.cornerRadius = 8
        createListingButton.addTarget(self, action: #selector(createListingTapped), for: .touchUpInside)

        myListingsButton.setTitle("Мои объявления", for: .normal)
        myListingsButton.backgroundColor = .black
        myListingsButton.layer.cornerRadius = 8
        myListingsButton.addTarget(self, action: #selector(myListingsTapped), for: .touchUpInside)

        let labelsStackView = UIStackView(arrangedSubviews: [nameLabel, phoneNumberLabel, emailLabel])
        labelsStackView.axis = .vertical
        labelsStackView.spacing = 10

        let buttonsStackView = UIStackView(arrangedSubviews: [
            editButton,
            changePasswordButton,
            createListingButton,
            myListingsButton,
            logoutButton
        ])
        buttonsStackView.axis = .vertical
        buttonsStackView.spacing = 15

        view.addSubview(labelsStackView)
        view.addSubview(buttonsStackView)

        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            labelsStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            labelsStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            labelsStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            buttonsStackView.topAnchor.constraint(equalTo: labelsStackView.bottomAnchor, constant: 30),
            buttonsStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonsStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            buttonsStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    private func setupLabel(_ label: UILabel, text: String) {
        label.text = text
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .black
        label.numberOfLines = 0
    }

    @objc private func editTapped() {
        presenter?.editUserProfile()
    }

    @objc private func changePasswordTapped() {
        presenter?.changePassword()
    }

    @objc private func logoutTapped() {
        presenter?.logout()
    }

    @objc private func createListingTapped() {
        presenter?.navigateToCreateListing()
    }

    @objc private func myListingsTapped() {
        presenter?.navigateToMyListings()
    }
    
    @objc private func refreshProfileData() {
        presenter?.loadUserProfile()
    }


    func showUserProfile(_ profile: UserProfile) {
        nameLabel.text = "Имя: \(profile.name)"
        phoneNumberLabel.text = "Телефон: \(profile.phone)"
        emailLabel.text = "Email: \(profile.email)"
    }

    func showError(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ОК", style: .default))
        present(alert, animated: true)
    }

    func showSuccess(message: String) {
        let alert = UIAlertController(title: "Успех", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ОК", style: .default))
        present(alert, animated: true)
    }
}
