import Foundation

extension Notification.Name {
    static let profileUpdated = Notification.Name("profileUpdated")
}
