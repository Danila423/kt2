import Foundation

protocol ProfilePresenterProtocol: AnyObject {
    func loadUserProfile()
    func editUserProfile()
    func changePassword()
    func logout()
    func navigateToCreateListing()
    func navigateToMyListings()
    

}

class ProfilePresenter: ProfilePresenterProtocol {
    weak var view: ProfileViewProtocol?
    var interactor: ProfileInteractorProtocol?
    var router: ProfileRouterProtocol?

    func loadUserProfile() {
        interactor?.fetchUserProfile { [weak self] result in
            switch result {
            case .success(let profile):
                self?.view?.showUserProfile(profile)
            case .failure(let error):
                self?.view?.showError(message: error.localizedDescription)
            }
        }
    }

    func editUserProfile() {
        router?.navigateToEditProfile()
    }

    func changePassword() {
        router?.navigateToChangePassword()
    }

    func logout() {
        interactor?.logoutUser { [weak self] result in
            switch result {
            case .success:
                self?.router?.navigateToLogin()
            case .failure(let error):
                self?.view?.showError(message: error.localizedDescription)
            }
        }
    }

    func navigateToCreateListing() {
        router?.navigateToCreateListing()
    }
    
    func navigateToMyListings() {
        router?.navigateToMyListings()
    }
}
