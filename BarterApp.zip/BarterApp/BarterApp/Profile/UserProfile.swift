public struct UserProfile: Codable {
    let id: Int
    let name: String
    let phone: String
    let email: String
}
