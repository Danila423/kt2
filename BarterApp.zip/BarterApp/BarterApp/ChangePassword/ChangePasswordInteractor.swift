import FirebaseAuth

protocol ChangePasswordInteractorProtocol: AnyObject {
    func changePassword(_ profile: UserProfile, currentPassword: String, newPassword: String, completion: @escaping (Result<Bool, Error>) -> Void)
    //func fetchUserProfile(completion: @escaping (Result<UserProfile, Error>) -> Void)
    //func updateUserProfile(_ profile: UserProfile, currentPassword: String, completion: @escaping (Result<Bool, Error>) -> Void)
    
}

class ChangePasswordInteractor: ChangePasswordInteractorProtocol {
    
    private let apiBaseUrl = "http://localhost:5000/api/users"

    
    func changePassword(_ profile: UserProfile, currentPassword: String, newPassword: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: "\(apiBaseUrl)/change-password/\(profile.id)") else {
            DispatchQueue.main.async {
                completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL"])))
            }
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "CurrentPassword": currentPassword,
            "NewPassword": newPassword
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                DispatchQueue.main.async {
                    let serverMessage = String(data: data ?? Data(), encoding: .utf8) ?? "Неизвестная ошибка"
                    completion(.failure(NSError(domain: "ServerError", code: -1, userInfo: [NSLocalizedDescriptionKey: serverMessage])))
                }
                return
            }

            DispatchQueue.main.async {
                completion(.success(true))
            }
        }.resume()
    }

}
