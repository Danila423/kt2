import UIKit

protocol ChangePasswordRouterProtocol: AnyObject {}

class ChangePasswordRouter: ChangePasswordRouterProtocol {
    weak var viewController: UIViewController?

    static func createModule() -> UIViewController {
        let view = ChangePasswordView()
        let presenter = ChangePasswordPresenter()
        let interactor = ChangePasswordInteractor()
        let router = ChangePasswordRouter()

        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        router.viewController = view

        return view
    }
}
