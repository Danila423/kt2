import UIKit

protocol ChangePasswordViewProtocol: AnyObject {
    func showSuccess(message: String)
    func showError(message: String)
}

class ChangePasswordView: UIViewController, ChangePasswordViewProtocol {
    var presenter: ChangePasswordPresenterProtocol?

    private let currentPasswordTextField = UITextField()
    private let newPasswordTextField = UITextField()
    private let saveButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .white
        title = "Изменение пароля"

        setupTextField(currentPasswordTextField, placeholder: "Текущий пароль")
        currentPasswordTextField.isSecureTextEntry = true
        setupTextField(newPasswordTextField, placeholder: "Новый пароль")
        newPasswordTextField.isSecureTextEntry = true

        saveButton.setTitle("Сохранить", for: .normal)
        saveButton.backgroundColor = .black
        saveButton.layer.cornerRadius = 8
        saveButton.addTarget(self, action: #selector(saveTapped), for: .touchUpInside)

        let stackView = UIStackView(arrangedSubviews: [
            currentPasswordTextField,
            newPasswordTextField,
            saveButton
        ])
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.alignment = .fill

        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    private func setupTextField(_ textField: UITextField, placeholder: String) {
        textField.placeholder = placeholder
        textField.borderStyle = .roundedRect
        textField.font = UIFont.systemFont(ofSize: 16)
    }

    @objc private func saveTapped() {
        guard let currentPassword = currentPasswordTextField.text, !currentPassword.isEmpty,
              let newPassword = newPasswordTextField.text, !newPassword.isEmpty else {
            showError(message: "Все поля должны быть заполнены")
            return
        }

        let userId = UserDefaults.standard.integer(forKey: "loggedInUserId")
        let userEmail = UserDefaults.standard.string(forKey: "loggedInUserEmail") ?? ""
        let userName = UserDefaults.standard.string(forKey: "loggedInUserName") ?? ""
        let userPhone = UserDefaults.standard.string(forKey: "loggedInUserPhone") ?? ""

        let profile = UserProfile(id: userId, name: userName, phone: userPhone, email: userEmail)

        presenter?.changePassword(profile, currentPassword: currentPassword, newPassword: newPassword)
    }


    func showSuccess(message: String) {
        let alert = UIAlertController(title: "Успех", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self] _ in
            self?.navigationController?.popViewController(animated: true)
        }))
        present(alert, animated: true)
    }

    func showError(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    

}
