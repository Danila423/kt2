import Foundation

protocol ChangePasswordPresenterProtocol: AnyObject {
    func changePassword(_ profile: UserProfile, currentPassword: String, newPassword: String)
}

class ChangePasswordPresenter: ChangePasswordPresenterProtocol {
    weak var view: ChangePasswordViewProtocol?
    var interactor: ChangePasswordInteractorProtocol?
    var router: ChangePasswordRouterProtocol?

    func changePassword(_ profile: UserProfile, currentPassword: String, newPassword: String) {
        
        interactor?.changePassword(profile, currentPassword: currentPassword, newPassword: newPassword) { [weak self] result in
            switch result {
            case .success:
                self?.view?.showSuccess(message: "Пароль успешно изменён")
            case .failure(let error):
                self?.view?.showError(message: error.localizedDescription)
            }
        }
         
    }

}
