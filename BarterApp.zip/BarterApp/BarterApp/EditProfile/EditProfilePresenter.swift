protocol EditProfilePresenterProtocol: AnyObject {
    func loadUserData()
    func saveUserData(_ profile: UserProfile, currentPassword: String)
}

class EditProfilePresenter: EditProfilePresenterProtocol {
    weak var view: EditProfileViewProtocol?
    var interactor: EditProfileInteractorProtocol?
    var router: EditProfileRouterProtocol?

    func loadUserData() {
        interactor?.fetchUserProfile { [weak self] result in
            switch result {
            case .success(let profile):
                self?.view?.populateUserData(profile)
            case .failure(let error):
                self?.view?.showError(message: error.localizedDescription)
            }
        }
    }

    func saveUserData(_ profile: UserProfile, currentPassword: String) {
        interactor?.updateUserProfile(profile, currentPassword: currentPassword) { [weak self] result in
            switch result {
            case .success:
                self?.view?.showSuccess(message: "Изменения сохранены")
                self?.router?.navigateBackToProfile()
            case .failure(let error):
                self?.view?.showError(message: error.localizedDescription)
            }
        }
    }
}
