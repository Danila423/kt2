import Foundation

protocol EditProfileInteractorProtocol: AnyObject {
    func fetchUserProfile(completion: @escaping (Result<UserProfile, Error>) -> Void)
    func updateUserProfile(_ profile: UserProfile, currentPassword: String, completion: @escaping (Result<Bool, Error>) -> Void)
}

class EditProfileInteractor: EditProfileInteractorProtocol {
    private let apiBaseUrl = "http://localhost:5000/api/users"
    func fetchUserProfile(completion: @escaping (Result<UserProfile, Error>) -> Void) {
        let userId = UserDefaults.standard.integer(forKey: "loggedInUserId")
        guard let url = URL(string: "\(apiBaseUrl)/profile/\(userId)") else {
            DispatchQueue.main.async {
                completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL"])))
            }
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "NoData", code: -1, userInfo: [NSLocalizedDescriptionKey: "Нет данных в ответе"])))
                }
                return
            }

            do {
                let profile = try JSONDecoder().decode(UserProfile.self, from: data)
                DispatchQueue.main.async {
                    completion(.success(profile))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }.resume()
    }

    func updateUserProfile(_ profile: UserProfile, currentPassword: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        let userId = UserDefaults.standard.integer(forKey: "loggedInUserId")
        guard let url = URL(string: "\(apiBaseUrl)/validate-password") else {
            DispatchQueue.main.async {
                completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL"])))
            }
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "userId": userId,
            "password": currentPassword
        ]
        
        
        let pass = currentPassword
        print("Отправляем запрос на \(url.absoluteString)")
        if let bodyData = try? JSONSerialization.data(withJSONObject: body, options: []),
           let jsonString = String(data: bodyData, encoding: .utf8) {
            print("Тело запроса: \(jsonString)")
        }

        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("Код ответа сервера: \(httpResponse.statusCode)")
            }

            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                print("Ответ от сервера: \(responseString)")
            }

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "InvalidPassword", code: -1, userInfo: [NSLocalizedDescriptionKey: "Неверный текущий пароль"])))
                }
                return
            }

            print("-----------------")
            self?.performProfileUpdate(profile,currentPassword: pass, completion: completion)
        }.resume()
    }

    private func performProfileUpdate(_ profile: UserProfile, currentPassword: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        let userId = UserDefaults.standard.integer(forKey: "loggedInUserId")
        guard let url = URL(string: "\(apiBaseUrl)/update/\(userId)") else {
            DispatchQueue.main.async {
                completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL"])))
            }
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "id": profile.id,
            "name": profile.name,
            "phone": profile.phone,
            "email": profile.email,
            "password": currentPassword
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        } catch {
            DispatchQueue.main.async {
                completion(.failure(error))
            }
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                let serverMessage = String(data: data ?? Data(), encoding: .utf8) ?? "Неизвестная ошибка"
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "ServerError", code: -1, userInfo: [NSLocalizedDescriptionKey: serverMessage])))
                }
                return
            }
            
            DispatchQueue.main.async {
                completion(.success(true))
            }
        }.resume()
    }
     
}
