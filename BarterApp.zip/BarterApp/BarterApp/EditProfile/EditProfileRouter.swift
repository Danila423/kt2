import UIKit

protocol EditProfileRouterProtocol: AnyObject {
    func navigateBackToProfile()
}

class EditProfileRouter: EditProfileRouterProtocol {
    weak var viewController: UIViewController?

    func navigateBackToProfile() {
        viewController?.navigationController?.popViewController(animated: true)
    }

    static func createModule() -> UIViewController {
        let view = EditProfileView()
        let presenter = EditProfilePresenter()
        let interactor = EditProfileInteractor()
        let router = EditProfileRouter()

        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        router.viewController = view

        return view
    }
}
