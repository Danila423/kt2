import UIKit

protocol EditProfileViewProtocol: AnyObject {
    func populateUserData(_ profile: UserProfile)
    func showSuccess(message: String)
    func showError(message: String)
}

class EditProfileView: UIViewController, EditProfileViewProtocol {
    var presenter: EditProfilePresenterProtocol?
    var onProfileUpdated: (() -> Void)?

    private let nameTextField = UITextField()
    private let phoneTextField = UITextField()
    private let emailTextField = UITextField()
    private let passwordTextField = UITextField()
    private let saveButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        presenter?.loadUserData()
    }

    private func setupUI() {
        view.backgroundColor = .white
        title = "Редактирование профиля"

        setupTextField(nameTextField, placeholder: "Имя")
        setupTextField(phoneTextField, placeholder: "Номер телефона")
        setupTextField(emailTextField, placeholder: "Почта")
        setupTextField(passwordTextField, placeholder: "Текущий пароль")
        passwordTextField.isSecureTextEntry = true

        saveButton.setTitle("Сохранить изменения", for: .normal)
        saveButton.backgroundColor = .black
        saveButton.layer.cornerRadius = 8
        saveButton.addTarget(self, action: #selector(saveTapped), for: .touchUpInside)

        let stackView = UIStackView(arrangedSubviews: [
            nameTextField,
            phoneTextField,
            emailTextField,
            passwordTextField,
            saveButton
        ])
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.alignment = .fill

        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    private func setupTextField(_ textField: UITextField, placeholder: String) {
        textField.placeholder = placeholder
        textField.borderStyle = .roundedRect
        textField.font = UIFont.systemFont(ofSize: 16)
    }
    
    @objc private func changePasswordTapped() {
        let changePasswordVC = ChangePasswordRouter.createModule()
        navigationController?.pushViewController(changePasswordVC, animated: true)
    }


    @objc private func saveTapped() {
        guard let name = nameTextField.text, !name.isEmpty,
              let phone = phoneTextField.text, !phone.isEmpty,
              let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showError(message: "Все поля должны быть заполнены")
            return
        }

        let updatedProfile = UserProfile(id: 0, name: name, phone: phone, email: email)
        presenter?.saveUserData(updatedProfile, currentPassword: password)
    }

    func populateUserData(_ profile: UserProfile) {
        nameTextField.text = profile.name
        phoneTextField.text = profile.phone
        emailTextField.text = profile.email
    }

    func showSuccess(message: String) {
        let alert = UIAlertController(title: "Успех", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self] _ in
            NotificationCenter.default.post(name: .profileUpdated, object: nil)
            self?.onProfileUpdated?()
            self?.navigationController?.popViewController(animated: true)
        }))
        present(alert, animated: true)
    }


    func showError(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
